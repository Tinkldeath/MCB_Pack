/********************************************************************************
** Form generated from reading UI file 'organizer.ui'
**
** Created by: Qt User Interface Compiler version 6.0.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ORGANIZER_H
#define UI_ORGANIZER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Organizer
{
public:
    QAction *actionVanish_mode;
    QAction *actionNormal_mode;
    QWidget *centralwidget;
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QPushButton *addEventButton;
    QLineEdit *lineSelectedEventDate;
    QSpacerItem *verticalSpacer_6;
    QSpacerItem *verticalSpacer_2;
    QTimeEdit *countdownEdit;
    QPushButton *stopCountButton;
    QLineEdit *lineSelectedEventFrequency;
    QLabel *label_7;
    QSpacerItem *verticalSpacer_7;
    QPushButton *deleteEventButton;
    QLabel *label_4;
    QSpacerItem *verticalSpacer_8;
    QLabel *label_11;
    QLineEdit *lineSelectedEventNotes;
    QLineEdit *lineSelectedEventHeader;
    QRadioButton *radioEnableAllButton;
    QLabel *label_8;
    QLabel *label_5;
    QLineEdit *lineSelecetedEventTime;
    QPushButton *changeEventButton;
    QPushButton *saveAndExitButton;
    QLabel *label_6;
    QRadioButton *radioDisableAllButton;
    QLabel *label;
    QLabel *label_2;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *verticalSpacer_5;
    QSpacerItem *verticalSpacer_4;
    QLabel *label_9;
    QLabel *label_3;
    QSpacerItem *verticalSpacer;
    QLabel *label_10;
    QPushButton *startCountButton;
    QLineEdit *lineCountdown;
    QPushButton *aboutButton;
    QListWidget *listWidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Organizer)
    {
        if (Organizer->objectName().isEmpty())
            Organizer->setObjectName(QString::fromUtf8("Organizer"));
        Organizer->resize(700, 600);
        Organizer->setMinimumSize(QSize(700, 600));
        Organizer->setMaximumSize(QSize(700, 600));
        Organizer->setContextMenuPolicy(Qt::NoContextMenu);
        Organizer->setToolButtonStyle(Qt::ToolButtonIconOnly);
        Organizer->setTabShape(QTabWidget::Rounded);
        actionVanish_mode = new QAction(Organizer);
        actionVanish_mode->setObjectName(QString::fromUtf8("actionVanish_mode"));
        actionNormal_mode = new QAction(Organizer);
        actionNormal_mode->setObjectName(QString::fromUtf8("actionNormal_mode"));
        centralwidget = new QWidget(Organizer);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout_2 = new QGridLayout(centralwidget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        addEventButton = new QPushButton(centralwidget);
        addEventButton->setObjectName(QString::fromUtf8("addEventButton"));

        gridLayout->addWidget(addEventButton, 5, 1, 1, 1);

        lineSelectedEventDate = new QLineEdit(centralwidget);
        lineSelectedEventDate->setObjectName(QString::fromUtf8("lineSelectedEventDate"));
        lineSelectedEventDate->setAlignment(Qt::AlignCenter);
        lineSelectedEventDate->setReadOnly(true);

        gridLayout->addWidget(lineSelectedEventDate, 7, 1, 1, 1);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_6, 3, 1, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 1, 1, 1, 1);

        countdownEdit = new QTimeEdit(centralwidget);
        countdownEdit->setObjectName(QString::fromUtf8("countdownEdit"));

        gridLayout->addWidget(countdownEdit, 14, 1, 1, 1);

        stopCountButton = new QPushButton(centralwidget);
        stopCountButton->setObjectName(QString::fromUtf8("stopCountButton"));

        gridLayout->addWidget(stopCountButton, 16, 0, 1, 1);

        lineSelectedEventFrequency = new QLineEdit(centralwidget);
        lineSelectedEventFrequency->setObjectName(QString::fromUtf8("lineSelectedEventFrequency"));
        lineSelectedEventFrequency->setReadOnly(true);

        gridLayout->addWidget(lineSelectedEventFrequency, 9, 1, 1, 1);

        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout->addWidget(label_7, 14, 0, 1, 1);

        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_7, 12, 0, 1, 1);

        deleteEventButton = new QPushButton(centralwidget);
        deleteEventButton->setObjectName(QString::fromUtf8("deleteEventButton"));

        gridLayout->addWidget(deleteEventButton, 11, 0, 1, 1);

        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 8, 0, 1, 1);

        verticalSpacer_8 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_8, 12, 1, 1, 1);

        label_11 = new QLabel(centralwidget);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout->addWidget(label_11, 6, 0, 1, 1);

        lineSelectedEventNotes = new QLineEdit(centralwidget);
        lineSelectedEventNotes->setObjectName(QString::fromUtf8("lineSelectedEventNotes"));
        lineSelectedEventNotes->setReadOnly(true);

        gridLayout->addWidget(lineSelectedEventNotes, 10, 1, 1, 1);

        lineSelectedEventHeader = new QLineEdit(centralwidget);
        lineSelectedEventHeader->setObjectName(QString::fromUtf8("lineSelectedEventHeader"));
        lineSelectedEventHeader->setReadOnly(true);

        gridLayout->addWidget(lineSelectedEventHeader, 6, 1, 1, 1);

        radioEnableAllButton = new QRadioButton(centralwidget);
        radioEnableAllButton->setObjectName(QString::fromUtf8("radioEnableAllButton"));
        radioEnableAllButton->setChecked(true);

        gridLayout->addWidget(radioEnableAllButton, 2, 1, 1, 1);

        label_8 = new QLabel(centralwidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_8, 13, 0, 1, 2);

        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 9, 0, 1, 1);

        lineSelecetedEventTime = new QLineEdit(centralwidget);
        lineSelecetedEventTime->setObjectName(QString::fromUtf8("lineSelecetedEventTime"));
        lineSelecetedEventTime->setAlignment(Qt::AlignCenter);
        lineSelecetedEventTime->setReadOnly(true);

        gridLayout->addWidget(lineSelecetedEventTime, 8, 1, 1, 1);

        changeEventButton = new QPushButton(centralwidget);
        changeEventButton->setObjectName(QString::fromUtf8("changeEventButton"));

        gridLayout->addWidget(changeEventButton, 11, 1, 1, 1);

        saveAndExitButton = new QPushButton(centralwidget);
        saveAndExitButton->setObjectName(QString::fromUtf8("saveAndExitButton"));

        gridLayout->addWidget(saveAndExitButton, 18, 1, 1, 1);

        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout->addWidget(label_6, 10, 0, 1, 1);

        radioDisableAllButton = new QRadioButton(centralwidget);
        radioDisableAllButton->setObjectName(QString::fromUtf8("radioDisableAllButton"));
        radioDisableAllButton->setIconSize(QSize(32, 32));

        gridLayout->addWidget(radioDisableAllButton, 2, 0, 1, 1);

        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setTextFormat(Qt::AutoText);
        label->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label, 0, 0, 1, 2);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_2, 4, 0, 1, 2);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_3, 17, 0, 1, 1);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_5, 3, 0, 1, 1);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_4, 17, 1, 1, 1);

        label_9 = new QLabel(centralwidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout->addWidget(label_9, 15, 0, 1, 1);

        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 7, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 1, 0, 1, 1);

        label_10 = new QLabel(centralwidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        gridLayout->addWidget(label_10, 5, 0, 1, 1);

        startCountButton = new QPushButton(centralwidget);
        startCountButton->setObjectName(QString::fromUtf8("startCountButton"));

        gridLayout->addWidget(startCountButton, 16, 1, 1, 1);

        lineCountdown = new QLineEdit(centralwidget);
        lineCountdown->setObjectName(QString::fromUtf8("lineCountdown"));

        gridLayout->addWidget(lineCountdown, 15, 1, 1, 1);

        aboutButton = new QPushButton(centralwidget);
        aboutButton->setObjectName(QString::fromUtf8("aboutButton"));

        gridLayout->addWidget(aboutButton, 18, 0, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);

        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));

        gridLayout_2->addWidget(listWidget, 0, 1, 1, 1);

        Organizer->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(Organizer);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        Organizer->setStatusBar(statusbar);

        retranslateUi(Organizer);

        QMetaObject::connectSlotsByName(Organizer);
    } // setupUi

    void retranslateUi(QMainWindow *Organizer)
    {
        Organizer->setWindowTitle(QCoreApplication::translate("Organizer", "Organizer", nullptr));
        actionVanish_mode->setText(QCoreApplication::translate("Organizer", "Vanish mode", nullptr));
        actionNormal_mode->setText(QCoreApplication::translate("Organizer", "Normal mode", nullptr));
        addEventButton->setText(QCoreApplication::translate("Organizer", "Add event", nullptr));
        stopCountButton->setText(QCoreApplication::translate("Organizer", "Clear", nullptr));
        label_7->setText(QCoreApplication::translate("Organizer", "Set countdown:", nullptr));
        deleteEventButton->setText(QCoreApplication::translate("Organizer", "Delete event", nullptr));
        label_4->setText(QCoreApplication::translate("Organizer", "Event time:", nullptr));
        label_11->setText(QCoreApplication::translate("Organizer", "Event header:", nullptr));
        radioEnableAllButton->setText(QCoreApplication::translate("Organizer", "Enable all", nullptr));
        label_8->setText(QCoreApplication::translate("Organizer", "<html><head/><body><p align=\"center\"><span style=\" font-size:18pt; font-weight:600;\">Countdown:</span></p></body></html>", nullptr));
        label_5->setText(QCoreApplication::translate("Organizer", "Event frequency:", nullptr));
        changeEventButton->setText(QCoreApplication::translate("Organizer", "Change event", nullptr));
        saveAndExitButton->setText(QCoreApplication::translate("Organizer", "Save and exit", nullptr));
        label_6->setText(QCoreApplication::translate("Organizer", "Event notes:", nullptr));
        radioDisableAllButton->setText(QCoreApplication::translate("Organizer", "Disable all notifications", nullptr));
        label->setText(QCoreApplication::translate("Organizer", "<html><head/><body><p align=\"center\"><span style=\" font-size:18pt; font-weight:600;\">Notifications:</span></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("Organizer", "<html><head/><body><p align=\"center\"><span style=\" font-size:18pt; font-weight:600;\">Events:</span></p></body></html>", nullptr));
        label_9->setText(QCoreApplication::translate("Organizer", "Countdown notes:", nullptr));
        label_3->setText(QCoreApplication::translate("Organizer", "Event date:", nullptr));
        label_10->setText(QCoreApplication::translate("Organizer", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600;\">Selected event:</span></p></body></html>", nullptr));
        startCountButton->setText(QCoreApplication::translate("Organizer", "Start", nullptr));
        aboutButton->setText(QCoreApplication::translate("Organizer", "About", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Organizer: public Ui_Organizer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ORGANIZER_H
