/********************************************************************************
** Form generated from reading UI file 'addevent.ui'
**
** Created by: Qt User Interface Compiler version 6.0.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDEVENT_H
#define UI_ADDEVENT_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTimeEdit>

QT_BEGIN_NAMESPACE

class Ui_AddEvent
{
public:
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QLabel *labelDateTime;
    QLabel *labelNotifications;
    QTimeEdit *timeEdit;
    QSpacerItem *verticalSpacer;
    QCalendarWidget *calendarWidget;
    QLabel *labelNotes;
    QLabel *labelEventHeader;
    QPushButton *addEventButton;
    QPlainTextEdit *plainTextEdit;
    QSpacerItem *verticalSpacer_3;
    QLabel *label_2;
    QPushButton *cancelButton;
    QComboBox *comboNotifications;
    QLabel *label;
    QLineEdit *lineEventHeader;
    QSpacerItem *verticalSpacer_2;
    QComboBox *comboMode;

    void setupUi(QDialog *AddEvent)
    {
        if (AddEvent->objectName().isEmpty())
            AddEvent->setObjectName(QString::fromUtf8("AddEvent"));
        AddEvent->resize(500, 500);
        AddEvent->setMinimumSize(QSize(500, 500));
        AddEvent->setMaximumSize(QSize(500, 500));
        AddEvent->setContextMenuPolicy(Qt::NoContextMenu);
        AddEvent->setSizeGripEnabled(true);
        AddEvent->setModal(true);
        gridLayout_2 = new QGridLayout(AddEvent);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        labelDateTime = new QLabel(AddEvent);
        labelDateTime->setObjectName(QString::fromUtf8("labelDateTime"));

        gridLayout->addWidget(labelDateTime, 0, 0, 1, 1);

        labelNotifications = new QLabel(AddEvent);
        labelNotifications->setObjectName(QString::fromUtf8("labelNotifications"));

        gridLayout->addWidget(labelNotifications, 4, 0, 1, 1);

        timeEdit = new QTimeEdit(AddEvent);
        timeEdit->setObjectName(QString::fromUtf8("timeEdit"));

        gridLayout->addWidget(timeEdit, 2, 1, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 1, 1, 1, 1);

        calendarWidget = new QCalendarWidget(AddEvent);
        calendarWidget->setObjectName(QString::fromUtf8("calendarWidget"));
        calendarWidget->setSelectedDate(QDate(2021, 6, 4));
        calendarWidget->setMinimumDate(QDate(2021, 6, 4));
        calendarWidget->setFirstDayOfWeek(Qt::Monday);
        calendarWidget->setGridVisible(true);
        calendarWidget->setHorizontalHeaderFormat(QCalendarWidget::ShortDayNames);
        calendarWidget->setVerticalHeaderFormat(QCalendarWidget::NoVerticalHeader);
        calendarWidget->setNavigationBarVisible(true);
        calendarWidget->setDateEditEnabled(false);

        gridLayout->addWidget(calendarWidget, 0, 1, 1, 1);

        labelNotes = new QLabel(AddEvent);
        labelNotes->setObjectName(QString::fromUtf8("labelNotes"));

        gridLayout->addWidget(labelNotes, 7, 0, 1, 1);

        labelEventHeader = new QLabel(AddEvent);
        labelEventHeader->setObjectName(QString::fromUtf8("labelEventHeader"));

        gridLayout->addWidget(labelEventHeader, 3, 0, 1, 1);

        addEventButton = new QPushButton(AddEvent);
        addEventButton->setObjectName(QString::fromUtf8("addEventButton"));

        gridLayout->addWidget(addEventButton, 9, 1, 1, 1);

        plainTextEdit = new QPlainTextEdit(AddEvent);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));

        gridLayout->addWidget(plainTextEdit, 7, 1, 1, 1);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_3, 8, 1, 1, 1);

        label_2 = new QLabel(AddEvent);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 5, 0, 1, 1);

        cancelButton = new QPushButton(AddEvent);
        cancelButton->setObjectName(QString::fromUtf8("cancelButton"));

        gridLayout->addWidget(cancelButton, 9, 0, 1, 1);

        comboNotifications = new QComboBox(AddEvent);
        comboNotifications->addItem(QString());
        comboNotifications->addItem(QString());
        comboNotifications->addItem(QString());
        comboNotifications->addItem(QString());
        comboNotifications->addItem(QString());
        comboNotifications->setObjectName(QString::fromUtf8("comboNotifications"));

        gridLayout->addWidget(comboNotifications, 4, 1, 1, 1);

        label = new QLabel(AddEvent);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 2, 0, 1, 1);

        lineEventHeader = new QLineEdit(AddEvent);
        lineEventHeader->setObjectName(QString::fromUtf8("lineEventHeader"));

        gridLayout->addWidget(lineEventHeader, 3, 1, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 6, 1, 1, 1);

        comboMode = new QComboBox(AddEvent);
        comboMode->addItem(QString());
        comboMode->addItem(QString());
        comboMode->addItem(QString());
        comboMode->setObjectName(QString::fromUtf8("comboMode"));

        gridLayout->addWidget(comboMode, 5, 1, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);


        retranslateUi(AddEvent);

        QMetaObject::connectSlotsByName(AddEvent);
    } // setupUi

    void retranslateUi(QDialog *AddEvent)
    {
        AddEvent->setWindowTitle(QCoreApplication::translate("AddEvent", "New event", nullptr));
        labelDateTime->setText(QCoreApplication::translate("AddEvent", "Date:", nullptr));
        labelNotifications->setText(QCoreApplication::translate("AddEvent", "Event frequency:", nullptr));
        labelNotes->setText(QCoreApplication::translate("AddEvent", "Event notes:", nullptr));
        labelEventHeader->setText(QCoreApplication::translate("AddEvent", "Event header:", nullptr));
        addEventButton->setText(QCoreApplication::translate("AddEvent", "Add event", nullptr));
        label_2->setText(QCoreApplication::translate("AddEvent", "Event mode:", nullptr));
        cancelButton->setText(QCoreApplication::translate("AddEvent", "Cancel", nullptr));
        comboNotifications->setItemText(0, QCoreApplication::translate("AddEvent", "One time", nullptr));
        comboNotifications->setItemText(1, QCoreApplication::translate("AddEvent", "Every hour", nullptr));
        comboNotifications->setItemText(2, QCoreApplication::translate("AddEvent", "Every day", nullptr));
        comboNotifications->setItemText(3, QCoreApplication::translate("AddEvent", "Every week", nullptr));
        comboNotifications->setItemText(4, QCoreApplication::translate("AddEvent", "Every month", nullptr));

        label->setText(QCoreApplication::translate("AddEvent", "Time:", nullptr));
        comboMode->setItemText(0, QCoreApplication::translate("AddEvent", "Push", nullptr));
        comboMode->setItemText(1, QCoreApplication::translate("AddEvent", "Dialog", nullptr));
        comboMode->setItemText(2, QCoreApplication::translate("AddEvent", "Spam", nullptr));

    } // retranslateUi

};

namespace Ui {
    class AddEvent: public Ui_AddEvent {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDEVENT_H
