/********************************************************************************
** Form generated from reading UI file 'editevent.ui'
**
** Created by: Qt User Interface Compiler version 6.0.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITEVENT_H
#define UI_EDITEVENT_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTimeEdit>

QT_BEGIN_NAMESPACE

class Ui_EditEvent
{
public:
    QGridLayout *gridLayout;
    QLabel *label_2;
    QPushButton *cancelButton;
    QCalendarWidget *calendarWidget;
    QPushButton *confirmButton;
    QLabel *label_4;
    QTimeEdit *timeEdit;
    QLabel *label;
    QLineEdit *lineNewHeader;
    QLabel *label_3;
    QPlainTextEdit *plainTextEdit;
    QLabel *label_5;
    QComboBox *comboBox;

    void setupUi(QDialog *EditEvent)
    {
        if (EditEvent->objectName().isEmpty())
            EditEvent->setObjectName(QString::fromUtf8("EditEvent"));
        EditEvent->resize(500, 500);
        EditEvent->setMinimumSize(QSize(500, 500));
        EditEvent->setMaximumSize(QSize(500, 500));
        gridLayout = new QGridLayout(EditEvent);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_2 = new QLabel(EditEvent);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        cancelButton = new QPushButton(EditEvent);
        cancelButton->setObjectName(QString::fromUtf8("cancelButton"));

        gridLayout->addWidget(cancelButton, 5, 0, 1, 1);

        calendarWidget = new QCalendarWidget(EditEvent);
        calendarWidget->setObjectName(QString::fromUtf8("calendarWidget"));
        calendarWidget->setMinimumDate(QDate(2021, 6, 5));
        calendarWidget->setGridVisible(true);
        calendarWidget->setVerticalHeaderFormat(QCalendarWidget::NoVerticalHeader);

        gridLayout->addWidget(calendarWidget, 0, 1, 1, 1);

        confirmButton = new QPushButton(EditEvent);
        confirmButton->setObjectName(QString::fromUtf8("confirmButton"));

        gridLayout->addWidget(confirmButton, 5, 1, 1, 1);

        label_4 = new QLabel(EditEvent);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 4, 0, 1, 1);

        timeEdit = new QTimeEdit(EditEvent);
        timeEdit->setObjectName(QString::fromUtf8("timeEdit"));

        gridLayout->addWidget(timeEdit, 1, 1, 1, 1);

        label = new QLabel(EditEvent);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        lineNewHeader = new QLineEdit(EditEvent);
        lineNewHeader->setObjectName(QString::fromUtf8("lineNewHeader"));

        gridLayout->addWidget(lineNewHeader, 2, 1, 1, 1);

        label_3 = new QLabel(EditEvent);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        plainTextEdit = new QPlainTextEdit(EditEvent);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));

        gridLayout->addWidget(plainTextEdit, 4, 1, 1, 1);

        label_5 = new QLabel(EditEvent);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 3, 0, 1, 1);

        comboBox = new QComboBox(EditEvent);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));

        gridLayout->addWidget(comboBox, 3, 1, 1, 1);


        retranslateUi(EditEvent);

        QMetaObject::connectSlotsByName(EditEvent);
    } // setupUi

    void retranslateUi(QDialog *EditEvent)
    {
        EditEvent->setWindowTitle(QCoreApplication::translate("EditEvent", "Change event", nullptr));
        label_2->setText(QCoreApplication::translate("EditEvent", "New time:", nullptr));
        cancelButton->setText(QCoreApplication::translate("EditEvent", "Cancel", nullptr));
        confirmButton->setText(QCoreApplication::translate("EditEvent", "Confirm", nullptr));
        label_4->setText(QCoreApplication::translate("EditEvent", "New notes:", nullptr));
        label->setText(QCoreApplication::translate("EditEvent", "New date:", nullptr));
        label_3->setText(QCoreApplication::translate("EditEvent", "New header:", nullptr));
        label_5->setText(QCoreApplication::translate("EditEvent", "New frequency:", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("EditEvent", "One time", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("EditEvent", "Every hour", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("EditEvent", "Every day", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("EditEvent", "Every week", nullptr));
        comboBox->setItemText(4, QCoreApplication::translate("EditEvent", "Every month", nullptr));

    } // retranslateUi

};

namespace Ui {
    class EditEvent: public Ui_EditEvent {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITEVENT_H
