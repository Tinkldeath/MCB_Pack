/********************************************************************************
** Form generated from reading UI file 'notification.ui'
**
** Created by: Qt User Interface Compiler version 6.0.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NOTIFICATION_H
#define UI_NOTIFICATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_notification
{
public:
    QGridLayout *gridLayout;
    QLabel *label;
    QPlainTextEdit *plainTextEdit;

    void setupUi(QWidget *notification)
    {
        if (notification->objectName().isEmpty())
            notification->setObjectName(QString::fromUtf8("notification"));
        notification->resize(300, 300);
        gridLayout = new QGridLayout(notification);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(notification);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        plainTextEdit = new QPlainTextEdit(notification);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        plainTextEdit->setReadOnly(true);

        gridLayout->addWidget(plainTextEdit, 1, 0, 1, 1);


        retranslateUi(notification);

        QMetaObject::connectSlotsByName(notification);
    } // setupUi

    void retranslateUi(QWidget *notification)
    {
        notification->setWindowTitle(QString());
        label->setText(QCoreApplication::translate("notification", "<html><head/><body><p align=\"center\"><span style=\" font-size:18pt; font-weight:600;\">Header</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class notification: public Ui_notification {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NOTIFICATION_H
