/****************************************************************************
** Meta object code from reading C++ file 'organizer.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.0.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../Organizer/organizer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'organizer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.0.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Organizer_t {
    const uint offsetsAndSize[34];
    char stringdata0[335];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_Organizer_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_Organizer_t qt_meta_stringdata_Organizer = {
    {
QT_MOC_LITERAL(0, 9), // "Organizer"
QT_MOC_LITERAL(10, 12), // "select_event"
QT_MOC_LITERAL(23, 0), // ""
QT_MOC_LITERAL(24, 11), // "QModelIndex"
QT_MOC_LITERAL(36, 3), // "ind"
QT_MOC_LITERAL(40, 25), // "on_addEventButton_clicked"
QT_MOC_LITERAL(66, 21), // "on_listWidget_clicked"
QT_MOC_LITERAL(88, 5), // "index"
QT_MOC_LITERAL(94, 28), // "on_saveAndExitButton_clicked"
QT_MOC_LITERAL(123, 28), // "on_changeEventButton_clicked"
QT_MOC_LITERAL(152, 28), // "on_deleteEventButton_clicked"
QT_MOC_LITERAL(181, 32), // "on_radioDisableAllButton_clicked"
QT_MOC_LITERAL(214, 31), // "on_radioEnableAllButton_clicked"
QT_MOC_LITERAL(246, 10), // "CheckEvent"
QT_MOC_LITERAL(257, 27), // "on_startCountButton_clicked"
QT_MOC_LITERAL(285, 26), // "on_stopCountButton_clicked"
QT_MOC_LITERAL(312, 22) // "on_aboutButton_clicked"

    },
    "Organizer\0select_event\0\0QModelIndex\0"
    "ind\0on_addEventButton_clicked\0"
    "on_listWidget_clicked\0index\0"
    "on_saveAndExitButton_clicked\0"
    "on_changeEventButton_clicked\0"
    "on_deleteEventButton_clicked\0"
    "on_radioDisableAllButton_clicked\0"
    "on_radioEnableAllButton_clicked\0"
    "CheckEvent\0on_startCountButton_clicked\0"
    "on_stopCountButton_clicked\0"
    "on_aboutButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Organizer[] = {

 // content:
       9,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   86,    2, 0x08,    0 /* Private */,
       5,    0,   89,    2, 0x08,    2 /* Private */,
       6,    1,   90,    2, 0x08,    3 /* Private */,
       8,    0,   93,    2, 0x08,    5 /* Private */,
       9,    0,   94,    2, 0x08,    6 /* Private */,
      10,    0,   95,    2, 0x08,    7 /* Private */,
      11,    0,   96,    2, 0x08,    8 /* Private */,
      12,    0,   97,    2, 0x08,    9 /* Private */,
      13,    0,   98,    2, 0x08,   10 /* Private */,
      14,    0,   99,    2, 0x08,   11 /* Private */,
      15,    0,  100,    2, 0x08,   12 /* Private */,
      16,    0,  101,    2, 0x08,   13 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 3,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Organizer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Organizer *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->select_event((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 1: _t->on_addEventButton_clicked(); break;
        case 2: _t->on_listWidget_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 3: _t->on_saveAndExitButton_clicked(); break;
        case 4: _t->on_changeEventButton_clicked(); break;
        case 5: _t->on_deleteEventButton_clicked(); break;
        case 6: _t->on_radioDisableAllButton_clicked(); break;
        case 7: _t->on_radioEnableAllButton_clicked(); break;
        case 8: _t->CheckEvent(); break;
        case 9: _t->on_startCountButton_clicked(); break;
        case 10: _t->on_stopCountButton_clicked(); break;
        case 11: _t->on_aboutButton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject Organizer::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_Organizer.offsetsAndSize,
    qt_meta_data_Organizer,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_Organizer_t

, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *Organizer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Organizer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Organizer.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Organizer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 12;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
