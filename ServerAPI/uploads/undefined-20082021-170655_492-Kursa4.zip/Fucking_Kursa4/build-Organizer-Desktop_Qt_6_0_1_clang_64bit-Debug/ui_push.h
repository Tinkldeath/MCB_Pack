/********************************************************************************
** Form generated from reading UI file 'push.ui'
**
** Created by: Qt User Interface Compiler version 6.0.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PUSH_H
#define UI_PUSH_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Push
{
public:
    QGridLayout *gridLayout;
    QLabel *labelNotes;
    QLabel *labelHeader;
    QToolButton *closeButton;

    void setupUi(QWidget *Push)
    {
        if (Push->objectName().isEmpty())
            Push->setObjectName(QString::fromUtf8("Push"));
        Push->resize(300, 120);
        gridLayout = new QGridLayout(Push);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        labelNotes = new QLabel(Push);
        labelNotes->setObjectName(QString::fromUtf8("labelNotes"));

        gridLayout->addWidget(labelNotes, 2, 0, 1, 2);

        labelHeader = new QLabel(Push);
        labelHeader->setObjectName(QString::fromUtf8("labelHeader"));
        labelHeader->setMinimumSize(QSize(0, 0));
        labelHeader->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(labelHeader, 0, 0, 2, 2);

        closeButton = new QToolButton(Push);
        closeButton->setObjectName(QString::fromUtf8("closeButton"));

        gridLayout->addWidget(closeButton, 3, 1, 1, 1);


        retranslateUi(Push);

        QMetaObject::connectSlotsByName(Push);
    } // setupUi

    void retranslateUi(QWidget *Push)
    {
        Push->setWindowTitle(QString());
        labelNotes->setText(QCoreApplication::translate("Push", "<html><head/><body><p><span style=\" font-size:10pt;\">Notes</span></p></body></html>", nullptr));
        labelHeader->setText(QCoreApplication::translate("Push", "<html><head/><body><p align=\"center\"><span style=\" font-size:24pt; font-weight:600; font-style:italic;\">Header</span></p></body></html>", nullptr));
        closeButton->setText(QCoreApplication::translate("Push", "Close", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Push: public Ui_Push {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PUSH_H
